import sqlite3
import os
import secrets
from werkzeug.security import generate_password_hash, check_password_hash

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "router_manager.db")
DEFAULT_ADMIN_USERNAME = "haing"
DEFAULT_ADMIN_PASSWORD = "291945"

def get_db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Settings table (key-value)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT
        )
    """)
    
    # Device nicknames table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS device_nicknames (
            mac_address TEXT PRIMARY KEY,
            nickname TEXT NOT NULL,
            description TEXT
        )
    """)

    # Users table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            is_active INTEGER DEFAULT 0,
            activated_by TEXT
        )
    """)

    # User sessions table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS user_sessions (
            token TEXT PRIMARY KEY,
            username TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # Insert default settings if not exists
    defaults = {
        "router_url": "http://192.168.1.1",
        "login_mode": "credentials",
        "username": "root",
        "password": "",
        "custom_cookie": ""
    }
    
    for key, value in defaults.items():
        cursor.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", (key, value))
        
    conn.commit()
    conn.close()


def ensure_default_admin_user():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT username FROM users WHERE username = ?", (DEFAULT_ADMIN_USERNAME,))
    row = cursor.fetchone()
    password_hash = generate_password_hash(DEFAULT_ADMIN_PASSWORD)

    if row:
        cursor.execute(
            "UPDATE users SET password_hash = ?, is_active = 1, activated_by = ? WHERE username = ?",
            (password_hash, "System (Default Admin)", DEFAULT_ADMIN_USERNAME)
        )
    else:
        cursor.execute(
            "INSERT INTO users (username, password_hash, is_active, activated_by) VALUES (?, ?, 1, ?)",
            (DEFAULT_ADMIN_USERNAME, password_hash, "System (Default Admin)")
        )

    conn.commit()
    conn.close()

def get_all_settings():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT key, value FROM settings")
    rows = cursor.fetchall()
    conn.close()
    return {row["key"]: row["value"] for row in rows}

def set_setting(key, value):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (key, value))
    conn.commit()
    conn.close()

def save_settings(settings_dict):
    conn = get_db_connection()
    cursor = conn.cursor()
    for key, value in settings_dict.items():
        cursor.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (key, str(value)))
    conn.commit()
    conn.close()

def get_all_nicknames():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT mac_address, nickname, description FROM device_nicknames")
    rows = cursor.fetchall()
    conn.close()
    return {row["mac_address"].lower(): {"nickname": row["nickname"], "description": row["description"]} for row in rows}

def set_nickname(mac, nickname, description=""):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT OR REPLACE INTO device_nicknames (mac_address, nickname, description) VALUES (?, ?, ?)",
        (mac.lower(), nickname, description)
    )
    conn.commit()
    conn.close()

def delete_nickname(mac):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM device_nicknames WHERE mac_address = ?", (mac.lower(),))
    conn.commit()
    conn.close()

# Initialize on import
init_db()
ensure_default_admin_user()

def register_user(username, password):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Check if this is the first user
    cursor.execute("SELECT COUNT(*) FROM users")
    count = cursor.fetchone()[0]
    
    # First user is automatically active, others are inactive
    is_active = 1 if count == 0 else 0
    activated_by = "System (First User)" if count == 0 else None
    
    password_hash = generate_password_hash(password)
    
    try:
        cursor.execute(
            "INSERT INTO users (username, password_hash, is_active, activated_by) VALUES (?, ?, ?, ?)",
            (username.lower().strip(), password_hash, is_active, activated_by)
        )
        conn.commit()
        success = True
        error_msg = None
    except sqlite3.IntegrityError:
        success = False
        error_msg = "Tài khoản đã tồn tại!"
    finally:
        conn.close()
        
    return success, error_msg

def authenticate_user(username, password):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT username, password_hash, is_active FROM users WHERE username = ?", (username.lower().strip(),))
    row = cursor.fetchone()
    conn.close()
    
    if not row:
        return False, "Tài khoản không tồn tại!", None
        
    if not check_password_hash(row["password_hash"], password):
        return False, "Sai mật khẩu!", None
        
    user_info = {
        "username": row["username"],
        "is_active": row["is_active"]
    }
    return True, None, user_info

def create_session(username):
    token = secrets.token_hex(32)
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO user_sessions (token, username) VALUES (?, ?)", (token, username.lower().strip()))
    conn.commit()
    conn.close()
    return token

def verify_session(token):
    if not token:
        return None
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT username FROM user_sessions WHERE token = ?", (token,))
    row = cursor.fetchone()
    conn.close()
    return row["username"] if row else None

def delete_session(token):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM user_sessions WHERE token = ?", (token,))
    conn.commit()
    conn.close()

def get_all_users():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT username, is_active, activated_by FROM users")
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]

def activate_user(username, activated_by):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "UPDATE users SET is_active = 1, activated_by = ? WHERE username = ?",
        (activated_by.lower().strip(), username.lower().strip())
    )
    conn.commit()
    conn.close()
