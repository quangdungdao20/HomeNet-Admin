from flask import Flask, request, make_response, redirect
import base64
import re

app = Flask(__name__)

# State of mock router
devices_js = """
function USERDevice(Domain,IpAddr,MacAddr,Port,IpType,DevType,DevStatus,PortType,Time,HostName,IPv4Enabled,IPv6Enabled,DeviceType) { 
  this.Domain = Domain; this.IpAddr = (IpAddr.length == 0)?"--":IpAddr; this.MacAddr= MacAddr; 
  this.Port = Port; this.PortType= PortType; this.DevStatus = DevStatus; this.IpType= IpType; 
  this.DevType= DevType; this.Time = Time; this.HostName= HostName; 
  this.IPv4Enabled = IPv4Enabled; this.IPv6Enabled = IPv6Enabled; this.DeviceType = DeviceType; 
}
var UserDevinfo = new Array(
  new USERDevice("InternetGatewayDevice.LANDevice.1.X_HW_UserDev.1","192\\x2e168\\x2e1\\x2e87","50\\x3a2b\\x3a73\\x3aaf\\x3a65\\x3a57","LAN3","DHCP","Linux\\x203\\x2e10","Online","ETH","5\\x3a28","MW3-502b73af6550","1","0","0"),
  new USERDevice("InternetGatewayDevice.LANDevice.1.X_HW_UserDev.2","192\\x2e168\\x2e1\\x2e22","94\\x3ac6\\x3a91\\x3aa9\\x3a40\\x3ae0","LAN1","Static","--","Online","ETH","11\\x3a26","","1","1","0"),
  new USERDevice("InternetGatewayDevice.LANDevice.1.X_HW_UserDev.3","192\\x2e168\\x2e1\\x2e89","30\\x3a34\\x3adb\\x3ac9\\x3a33\\x3a40","SSID1","DHCP","","Online","WIFI","0\\x3a38","LGE_AIR2_open","1","1","0"),
  new USERDevice("InternetGatewayDevice.LANDevice.1.X_HW_UserDev.4","192\\x2e168\\x2e1\\x2e88","60\\x3a23\\x3aa4\\x3aca\\x3a60\\x3ac8","SSID1","DHCP","udhcp","Online","WIFI","4\\x3a3","D94559976","1","1","0"),
  new USERDevice("InternetGatewayDevice.LANDevice.1.X_HW_UserDev.8","192\\x2e168\\x2e1\\x2e114","2a\\x3a3f\\x3a92\\x3aa7\\x3af9\\x3ad2","SSID0","DHCP","","Offline","WIFI","156\\x3a0","","1","0","0"),
  null
);
"""

mac_filter_rules = [
    {"domain": "InternetGatewayDevice.X_HW_Security.MacFilter.1", "mac": "60\\x3a23\\x3aa4\\x3aca\\x3a60\\x3ac8"}
]
enable_filter = "1"
filter_mode = "0" # Blacklist
ont_token = "mock_token_11da47399c5e9dc5134248"

def is_authorized():
    cookie = request.headers.get("Cookie", "")
    # Check if we have the mock sid cookie
    if "sid=mock_sid_98765" in cookie:
        return True
    # Or check if login credentials cookie is present (like UserName:admin:PassWord:...)
    if "UserName:" in cookie and "PassWord:" in cookie:
        return True
    return False

@app.route("/asp/GetRandCount.asp", methods=["GET", "POST"])
def get_rand_count():
    return ont_token

@app.route("/login.cgi", methods=["POST"])
def login():
    cookie = request.headers.get("Cookie", "")
    token = request.form.get("x.X_HW_Token", "")
    
    # Simple validation: expect telecomadmin / admintelecom (base64 is YWRtaW50ZWxlY29t) or root / admin (base64 is YWRtaW4=)
    is_valid = False
    if "UserName:telecomadmin" in cookie and "PassWord:YWRtaW50ZWxlY29t" in cookie:
        is_valid = True
    elif "UserName:root" in cookie and "PassWord:YWRtaW4=" in cookie:
        is_valid = True
    elif "UserName:admin" in cookie and "PassWord:YWRtaW4=" in cookie:
        is_valid = True
        
    if is_valid:
        resp = make_response("<html><body>Login Success</body></html>")
        # Set the mock session cookie
        resp.headers["Set-Cookie"] = "sid=mock_sid_98765:Language:english:id=1; Path=/"
        return resp
    else:
        return "<html><body>Login Failed! Invalid Cookie Credentials</body></html>", 401

@app.route("/html/bbsp/common/lanuserinfo.asp", methods=["GET"])
def get_lan_user_info():
    if not is_authorized():
        return "Unauthorized", 401
    resp = make_response(devices_js)
    resp.headers["Content-Type"] = "application/javascript"
    return resp

@app.route("/html/bbsp/macfilter/macfilter.asp", methods=["GET"])
def get_mac_filter_page():
    if not is_authorized():
        return "Unauthorized", 401
    
    # Generate MacFilter JS array
    mac_filter_items = []
    for item in mac_filter_rules:
        mac_filter_items.append(f'new stMacFilter("{item["domain"]}","{item["mac"]}")')
    mac_filter_items_str = ", ".join(mac_filter_items) + ", null"
    
    html = f"""
    <html>
    <head>
        <script>
            var enableFilter = '{enable_filter}';
            var Mode = '{filter_mode}';
            function stMacFilter(domain, MACAddress) {{
                this.domain = domain;
                this.MACAddress = MACAddress;
            }}
            var MacFilter = new Array({mac_filter_items_str});
        </script>
    </head>
    <body>
        <input type="hidden" name="onttoken" id="hwonttoken" value="{ont_token}">
    </body>
    </html>
    """
    return html

@app.route("/html/bbsp/macfilter/add.cgi", methods=["POST"])
def add_mac_filter():
    if not is_authorized():
        return "Unauthorized", 401
    
    token = request.form.get("x.X_HW_Token", "")
    mac = request.form.get("x.SourceMACAddress", "")
    
    if not mac:
        return "Missing MAC", 400
        
    # Format the MAC address to hex-escaped for simulation (e.g. 00\x3a11\x3a...)
    escaped_mac = mac.lower().replace(":", "\\x3a")
    
    # Check if duplicate
    for item in mac_filter_rules:
        if item["mac"].lower() == escaped_mac:
            return "Duplicate MAC", 400
            
    new_id = len(mac_filter_rules) + 1
    new_domain = f"InternetGatewayDevice.X_HW_Security.MacFilter.{new_id}"
    mac_filter_rules.append({"domain": new_domain, "mac": escaped_mac})
    
    return "MAC filter added successfully"

@app.route("/html/bbsp/macfilter/set.cgi", methods=["POST"])
def set_mac_filter():
    global enable_filter, filter_mode
    if not is_authorized():
        return "Unauthorized", 401
        
    domain = request.args.get("x", "")
    
    right = request.form.get("x.MacFilterRight", None)
    policy = request.form.get("x.MacFilterPolicy", None)
    
    if right is not None:
        enable_filter = right
    if policy is not None:
        filter_mode = policy
        
    return "Settings updated successfully"

@app.route("/html/bbsp/macfilter/del.cgi", methods=["POST"])
def del_mac_filter():
    global mac_filter_rules
    if not is_authorized():
        return "Unauthorized", 401
        
    # In HG8245H, the request body contains fields like:
    # "InternetGatewayDevice.X_HW_Security.MacFilter.1": ""
    # We will search the form parameters to see which domain is passed
    target_domain = None
    for key in request.form.keys():
        if "InternetGatewayDevice.X_HW_Security.MacFilter" in key:
            target_domain = key
            break
            
    if not target_domain:
        return "No domain found to delete", 400
        
    mac_filter_rules = [item for item in mac_filter_rules if item["domain"] != target_domain]
    return "MAC filter deleted successfully"

if __name__ == "__main__":
    print("Starting mock router at http://127.0.0.1:8080...")
    app.run(host="127.0.0.1", port=8080, debug=True)
