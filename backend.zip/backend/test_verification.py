import requests
import json
import time

BACKEND_URL = "http://127.0.0.1:5000/api"

def run_tests():
    print("--- 1. Saving settings to point to Mock Router (http://127.0.0.1:8080) ---")
    settings_payload = {
        "router_url": "http://127.0.0.1:8080",
        "login_mode": "credentials",
        "username": "telecomadmin",
        "password": "admintelecom"
    }
    
    resp = requests.post(f"{BACKEND_URL}/settings", json=settings_payload)
    print("POST /settings response:", resp.status_code, json.dumps(resp.json(), ensure_ascii=True))
    assert resp.status_code == 200, "Settings save failed"
    
    print("\n--- 2. Checking router connection status ---")
    resp = requests.get(f"{BACKEND_URL}/status")
    print("GET /status response:", resp.status_code, json.dumps(resp.json(), ensure_ascii=True))
    assert resp.json().get("status") == "connected", "Connection failed"

    print("\n--- 3. Fetching devices ---")
    resp = requests.get(f"{BACKEND_URL}/devices")
    print("GET /devices response:", resp.status_code)
    devices = resp.json()
    print(f"Found {len(devices)} devices:")
    for d in devices:
        print(f"  - IP: {d['ip']}, MAC: {d['mac']}, Name: {d['hostname']}, Port: {d['port']}, Status: {d['status']}")
    assert len(devices) > 0, "No devices parsed"

    print("\n--- 4. Updating device nickname ---")
    target_mac = devices[0]['mac']
    nickname_payload = {
        "mac": target_mac,
        "nickname": "Máy của Bố",
        "description": "Laptop Asus đen"
    }
    resp = requests.post(f"{BACKEND_URL}/devices/nickname", json=nickname_payload)
    print("POST /devices/nickname response:", resp.status_code, json.dumps(resp.json(), ensure_ascii=True))
    
    print("\n--- 5. Verifying nickname in devices list ---")
    resp = requests.get(f"{BACKEND_URL}/devices")
    updated_devices = resp.json()
    target_device = next((d for d in updated_devices if d['mac'] == target_mac), None)
    print("Updated device info:", json.dumps(target_device, ensure_ascii=True))
    assert target_device is not None
    assert target_device['nickname'] == "Máy của Bố", "Nickname update failed"

    print("\n--- 6. Fetching MAC filter status and rules ---")
    resp = requests.get(f"{BACKEND_URL}/macfilter")
    filter_info = resp.json()
    print("GET /macfilter response:", resp.status_code, json.dumps(filter_info, ensure_ascii=True))
    assert filter_info['enable_filter'] == True, "Filter toggle mismatch"
    assert len(filter_info['rules']) == 1, "Rules length mismatch"
    token = filter_info['token']

    print("\n--- 7. Adding a new MAC filter rule ---")
    new_mac = "2a:3f:92:a7:f9:d2"
    add_payload = {
        "mac": new_mac,
        "token": token
    }
    resp = requests.post(f"{BACKEND_URL}/macfilter/add", json=add_payload)
    print("POST /macfilter/add response:", resp.status_code, json.dumps(resp.json(), ensure_ascii=True))
    
    # Verify add
    resp = requests.get(f"{BACKEND_URL}/macfilter")
    rules = resp.json()['rules']
    print("Updated rules:", json.dumps(rules, ensure_ascii=True))
    assert any(r['mac'] == new_mac.replace(":", "\\x3a") for r in rules), "MAC rule add failed"

    print("\n--- 8. Toggling MAC filter to False (disabled) ---")
    toggle_payload = {
        "enable": False,
        "token": token
    }
    resp = requests.post(f"{BACKEND_URL}/macfilter/toggle", json=toggle_payload)
    print("POST /macfilter/toggle response:", resp.status_code, json.dumps(resp.json(), ensure_ascii=True))
    
    # Verify toggle
    resp = requests.get(f"{BACKEND_URL}/macfilter")
    print("Updated filter info after toggle:", json.dumps(resp.json(), ensure_ascii=True))
    assert resp.json()['enable_filter'] == False, "Filter toggle off failed"

    print("\n--- 9. Changing filtering mode to Whitelist ('1') ---")
    mode_payload = {
        "mode": "1",
        "token": token
    }
    resp = requests.post(f"{BACKEND_URL}/macfilter/mode", json=mode_payload)
    print("POST /macfilter/mode response:", resp.status_code, json.dumps(resp.json(), ensure_ascii=True))
    
    # Verify mode
    resp = requests.get(f"{BACKEND_URL}/macfilter")
    print("Updated filter info after mode change:", json.dumps(resp.json(), ensure_ascii=True))
    assert resp.json()['filter_mode'] == "1", "Filter mode change failed"

    print("\n--- 10. Deleting a MAC filter rule ---")
    # Let's delete the first rule
    target_domain = rules[0]['domain']
    del_payload = {
        "domain": target_domain,
        "token": token
    }
    resp = requests.post(f"{BACKEND_URL}/macfilter/delete", json=del_payload)
    print("POST /macfilter/delete response:", resp.status_code, json.dumps(resp.json(), ensure_ascii=True))
    
    # Verify delete
    resp = requests.get(f"{BACKEND_URL}/macfilter")
    print("Final rules list:", json.dumps(resp.json()['rules'], ensure_ascii=True))
    assert not any(r['domain'] == target_domain for r in resp.json()['rules']), "Rule deletion failed"

    print("\n==================================")
    print("TẤT CẢ CÁC BÀI KIỂM TRA ĐÃ THÀNH CÔNG!")
    print("==================================")

if __name__ == "__main__":
    run_tests()
