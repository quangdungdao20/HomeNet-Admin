from flask import Flask, request, jsonify, make_response, g
import requests
import base64
import re
import os
import urllib.parse
import database

app = Flask(__name__)

# Global session instance
router_session = requests.Session()

def get_router_session():
    return router_session

def add_cors(response):
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type,Authorization,Cookie"
    response.headers["Access-Control-Allow-Methods"] = "GET,POST,PUT,DELETE,OPTIONS"
    return response

@app.after_request
def after_request(response):
    return add_cors(response)

@app.route("/", defaults={"path": ""}, methods=["OPTIONS"])
@app.route("/<path:path>", methods=["OPTIONS"])
def handle_options(path):
    resp = make_response()
    return add_cors(resp)

# Middleware: Check authentication for API requests
@app.before_request
def check_auth():
    if request.method == "OPTIONS":
        return
        
    # Exclude login and register from auth checks
    if request.path in ["/api/auth/login", "/api/auth/register"]:
        return
        
    # Only verify auth on API endpoints
    if not request.path.startswith("/api/"):
        return
        
    auth_header = request.headers.get("Authorization")
    if not auth_header or not auth_header.startswith("Bearer "):
        return jsonify({"error": "Unauthorized"}), 401
        
    token = auth_header.split(" ")[1]
    username = database.verify_session(token)
    if not username:
        return jsonify({"error": "Unauthorized"}), 401
        
    # Store verified username in Flask request context g
    g.username = username

# --- Authentication & User Endpoints ---

@app.route("/api/auth/register", methods=["POST"])
def register():
    data = request.json or {}
    username = data.get("username", "").strip()
    password = data.get("password", "").strip()
    
    if not username or not password:
        return jsonify({"error": "Vui lòng nhập đầy đủ tài khoản và mật khẩu!"}), 400
        
    if len(password) < 6:
        return jsonify({"error": "Mật khẩu phải chứa ít nhất 6 ký tự!"}), 400
        
    success, error_msg = database.register_user(username, password)
    if success:
        all_users = database.get_all_users()
        user_record = next((u for u in all_users if u["username"] == username.lower()), None)
        is_active = user_record["is_active"] if user_record else 0
        
        if is_active:
            return jsonify({"success": True, "message": "Đăng ký tài khoản quản trị đầu tiên thành công và đã tự động kích hoạt!"})
        else:
            return jsonify({"success": True, "message": "Đăng ký thành công! Vui lòng nhờ người dùng đã kích hoạt duyệt kích hoạt tài khoản."})
    else:
        return jsonify({"error": error_msg}), 400

@app.route("/api/auth/login", methods=["POST"])
def login():
    data = request.json or {}
    username = data.get("username", "").strip()
    password = data.get("password", "").strip()
    
    if not username or not password:
        return jsonify({"error": "Vui lòng nhập đầy đủ tài khoản và mật khẩu!"}), 400
        
    success, error_msg, user_info = database.authenticate_user(username, password)
    if not success:
        return jsonify({"error": error_msg}), 400
        
    if not user_info["is_active"]:
        return jsonify({"error": "Tài khoản của bạn chưa được kích hoạt! Hãy liên hệ người dùng đã kích hoạt để kích hoạt tài khoản."}), 403
        
    token = database.create_session(username)
    return jsonify({
        "success": True,
        "token": token,
        "username": user_info["username"],
        "message": "Đăng nhập thành công!"
    })

@app.route("/api/auth/logout", methods=["POST"])
def logout():
    auth_header = request.headers.get("Authorization")
    if auth_header and auth_header.startswith("Bearer "):
        token = auth_header.split(" ")[1]
        database.delete_session(token)
    return jsonify({"success": True, "message": "Đã đăng xuất."})

@app.route("/api/auth/me", methods=["GET"])
def me():
    return jsonify({"username": g.username})

@app.route("/api/users", methods=["GET"])
def get_users_endpoint():
    users_list = database.get_all_users()
    return jsonify(users_list)

@app.route("/api/users/activate", methods=["POST"])
def activate_user_endpoint():
    data = request.json or {}
    target_username = data.get("username", "").strip()
    
    if not target_username:
        return jsonify({"error": "Thiếu tên tài khoản cần kích hoạt"}), 400
        
    database.activate_user(target_username, g.username)
    return jsonify({"success": True, "message": f"Kích hoạt tài khoản {target_username} thành công!"})

# Helper: Unescape JS hex encoding (e.g. \\x2e -> .)
def unescape_js_hex(text):
    if not text:
        return ""
    return re.sub(r'\\x([0-9a-fA-F]{2})', lambda m: chr(int(m.group(1), 16)), text)

# Helper: Get current router configuration
def get_config():
    return database.get_all_settings()

# Function to execute login on router
def do_router_login():
    config = get_config()
    url = config.get("router_url", "http://192.168.1.1").rstrip("/")
    mode = config.get("login_mode", "credentials")
    
    session = get_router_session()
    session.headers.clear()
    
    if mode == "cookie":
        cookie_val = config.get("custom_cookie", "")
        if cookie_val:
            session.headers["Cookie"] = cookie_val
            print("Session initialized using manual Cookie header.")
        return True
        
    username = config.get("username", "")
    password = config.get("password", "")
    
    print(f"Attempting login to router {url} with username '{username}'...")
    
    try:
        # Step 1: Fetch GetRandCount.asp to retrieve the CSRF token
        token = ""
        try:
            token_resp = session.post(f"{url}/asp/GetRandCount.asp", timeout=5)
            if token_resp.status_code == 200:
                token = token_resp.text.strip()
                print(f"Retrieved login token: {token}")
        except Exception as e:
            print(f"Failed to fetch /asp/GetRandCount.asp: {e}. Attempting login without token.")
            
        # Step 2: Encode password in Base64
        pass_b64 = base64.b64encode(password.encode("utf-8")).decode("utf-8")
        
        # Step 3: Construct the login cookie header
        login_cookie = f"UserName:{username}:PassWord:{pass_b64}:Language:english:id=-1"
        session.headers["Cookie"] = login_cookie
        
        # Step 4: Submit post request to login.cgi
        payload = {}
        if token:
            payload["x.X_HW_Token"] = token
            
        login_resp = session.post(f"{url}/login.cgi", data=payload, timeout=5)
        print(f"Login request submitted. Status: {login_resp.status_code}")
        
        # Step 5: Check if router returned a new session Cookie (e.g. sid=...)
        # We manually check the response headers for 'Set-Cookie'
        set_cookie = login_resp.headers.get("Set-Cookie", "")
        if "sid=" in set_cookie:
            # Parse out the sid cookie value
            sid_match = re.search(r'(sid=[^;]+)', set_cookie)
            if sid_match:
                new_cookie = sid_match.group(1)
                # Huawei sid cookies often end with :Language:english:id=1
                # Let's see if we can construct the full colon-separated string if needed
                if ":" not in new_cookie:
                    new_cookie = f"{new_cookie}:Language:english:id=1"
                session.headers["Cookie"] = new_cookie
                database.set_setting("active_session_cookie", new_cookie)
                print(f"Saved active session cookie: {new_cookie}")
                
        return True
    except Exception as e:
        print(f"Error during login: {e}")
        return False

# Middleware to perform requests with automatic relogin
def make_router_request(method, endpoint, data=None, params=None):
    config = get_config()
    url = config.get("router_url", "http://192.168.1.1").rstrip("/")
    full_url = f"{url}/{endpoint.lstrip('/')}"
    session = get_router_session()
    
    # Ensure active session cookie is set in headers if we have one saved
    saved_cookie = config.get("active_session_cookie", "")
    if saved_cookie and "Cookie" not in session.headers:
        session.headers["Cookie"] = saved_cookie
        
    try:
        if method.upper() == "GET":
            resp = session.get(full_url, params=params, timeout=5)
        else:
            resp = session.post(full_url, data=data, params=params, timeout=5)
            
        # Check if the page indicates that we need to login
        # Usually, when logged out, the router redirects to login.asp or returns login form
        is_logged_out = False
        if resp.status_code == 401 or "login.asp" in resp.url or "login.cgi" in resp.url:
            is_logged_out = True
        elif resp.status_code == 200 and ("UserName" in resp.text and "PassWord" in resp.text and "GetRandCount" in resp.text):
            is_logged_out = True
            
        if is_logged_out:
            print("Session expired or unauthorized. Re-logging in...")
            if do_router_login():
                # Retry request once
                if method.upper() == "GET":
                    resp = session.get(full_url, params=params, timeout=5)
                else:
                    resp = session.post(full_url, data=data, params=params, timeout=5)
            else:
                raise Exception("Đăng nhập vào Router thất bại.")
                
        return resp
    except Exception as e:
        print(f"Router request error ({endpoint}): {e}")
        raise e

# --- API Endpoints ---

@app.route("/api/status", methods=["GET"])
def get_status():
    try:
        # Check if we can reach the router settings page or status page
        resp = make_router_request("GET", "/html/bbsp/common/lanuserinfo.asp")
        if resp.status_code == 200:
            return jsonify({"status": "connected", "message": "Kết nối router thành công."})
        return jsonify({"status": "error", "message": f"Router trả về mã lỗi: {resp.status_code}"})
    except Exception as e:
        return jsonify({"status": "disconnected", "message": f"Không thể kết nối: {str(e)}"})

@app.route("/api/settings", methods=["GET"])
def get_settings():
    settings = database.get_all_settings()
    # Mask password for security
    if settings.get("password"):
        settings["password"] = "********"
    return jsonify(settings)

@app.route("/api/settings", methods=["POST"])
def save_settings():
    data = request.json or {}
    
    # Get existing settings first to retain password if masked
    existing = database.get_all_settings()
    
    # Prepare update dict
    update = {}
    for key in ["router_url", "login_mode", "username", "custom_cookie"]:
        if key in data:
            update[key] = data[key]
            
    if "password" in data:
        if data["password"] == "********":
            # Retain existing password
            pass
        else:
            update["password"] = data["password"]
            
    # Clear session cookie when settings change to force re-login
    update["active_session_cookie"] = ""
    
    database.save_settings(update)
    
    # Clear current headers to force fresh login with new credentials
    router_session.headers.clear()
    
    # Try logging in right away to verify settings
    success = do_router_login()
    
    if success:
        return jsonify({"success": True, "message": "Đã lưu cài đặt và đăng nhập thành công!"})
    else:
        return jsonify({"success": True, "warning": True, "message": "Đã lưu cài đặt nhưng đăng nhập thất bại. Vui lòng kiểm tra lại thông tin."})

@app.route("/api/devices", methods=["GET"])
def get_devices():
    try:
        resp = make_router_request("GET", "/html/bbsp/common/lanuserinfo.asp")
        js_content = resp.text
        
        # Normalize content
        normalized = js_content.replace('\r', '').replace('\n', '')
        
        # Regex to find arguments of new USERDevice(...)
        matches = re.findall(r'new\s+USERDevice\((.*?)\)', normalized)
        
        devices = []
        nicknames = database.get_all_nicknames()
        
        for match in matches:
            # Extract arguments
            args = re.findall(r'"([^"]*)"', match)
            if len(args) >= 10:
                domain = unescape_js_hex(args[0])
                ip = unescape_js_hex(args[1])
                mac = unescape_js_hex(args[2])
                port = unescape_js_hex(args[3])
                ip_type = unescape_js_hex(args[4])
                dev_type = unescape_js_hex(args[5])
                status = unescape_js_hex(args[6])
                port_type = unescape_js_hex(args[7])
                duration = unescape_js_hex(args[8])
                hostname = unescape_js_hex(args[9])
                
                instid = domain.split('.')[-1]
                mac_lower = mac.lower()
                
                # Check for nickname in database
                nickname_info = nicknames.get(mac_lower, {"nickname": "", "description": ""})
                
                devices.append({
                    "domain": domain,
                    "instid": instid,
                    "ip": ip,
                    "mac": mac,
                    "port": port,
                    "ip_type": ip_type,
                    "dev_type": dev_type,
                    "status": status,
                    "port_type": port_type,
                    "duration": duration,
                    "hostname": hostname,
                    "nickname": nickname_info["nickname"],
                    "description": nickname_info["description"]
                })
                
        return jsonify(devices)
    except Exception as e:
        return jsonify({"error": f"Lỗi lấy danh sách thiết bị: {str(e)}"}), 500

@app.route("/api/devices/nickname", methods=["POST"])
def update_nickname():
    data = request.json or {}
    mac = data.get("mac")
    nickname = data.get("nickname")
    description = data.get("description", "")
    
    if not mac or not nickname:
        return jsonify({"error": "Thiếu MAC address hoặc biệt danh"}), 400
        
    database.set_nickname(mac, nickname, description)
    return jsonify({"success": True, "message": "Cập nhật biệt danh thành công!"})

@app.route("/api/devices/nickname/<mac>", methods=["DELETE"])
def remove_nickname(mac):
    database.delete_nickname(mac)
    return jsonify({"success": True, "message": "Đã xoá biệt danh."})

@app.route("/api/macfilter", methods=["GET"])
def get_mac_filter():
    try:
        resp = make_router_request("GET", "/html/bbsp/macfilter/macfilter.asp")
        html_content = resp.text
        
        # 1. Parse rules
        enable_filter = "0"
        filter_mode = "0"
        rules = []
        
        ef_match = re.search(r"var\s+enableFilter\s*=\s*'([^']*)'", html_content)
        if ef_match:
            enable_filter = ef_match.group(1)
            
        mode_match = re.search(r"var\s+Mode\s*=\s*'([^']*)'", html_content)
        if mode_match:
            filter_mode = mode_match.group(1)
            
        # Parse items: new stMacFilter("domain", "mac")
        matches = re.findall(r'new\s+stMacFilter\((.*?)\)', html_content)
        for match in matches:
            args = re.findall(r'"([^"]*)"', match)
            if len(args) >= 2:
                domain = unescape_js_hex(args[0])
                mac = unescape_js_hex(args[1])
                rules.append({
                    "domain": domain,
                    "mac": mac
                })
                
        # 2. Extract Token
        token = ""
        token_match = re.search(r'id=["\']hwonttoken["\']\s+value=["\']([^"\']*)["\']', html_content)
        if not token_match:
            token_match = re.search(r'name=["\']onttoken["\']\s+value=["\']([^"\']*)["\']', html_content)
        if not token_match:
            token_match = re.search(r'value=["\']([^"\']*)["\']\s+id=["\']hwonttoken["\']', html_content)
        if token_match:
            token = token_match.group(1)
            
        return jsonify({
            "enable_filter": enable_filter == "1",
            "filter_mode": filter_mode, # "0" = Blacklist, "1" = Whitelist
            "rules": rules,
            "token": token
        })
    except Exception as e:
        return jsonify({"error": f"Lỗi lấy thông tin lọc MAC: {str(e)}"}), 500

@app.route("/api/macfilter/toggle", methods=["POST"])
def toggle_mac_filter():
    data = request.json or {}
    enable = data.get("enable") # Boolean
    token = data.get("token")
    
    if enable is None or not token:
        return jsonify({"error": "Thiếu tham số 'enable' hoặc 'token'"}), 400
        
    val = "1" if enable else "0"
    payload = {
        "x.MacFilterRight": val,
        "x.X_HW_Token": token
    }
    
    try:
        # Action is relative to macfilter.asp: set.cgi
        resp = make_router_request(
            "POST", 
            "/html/bbsp/macfilter/set.cgi?x=InternetGatewayDevice.X_HW_Security&RequestFile=html/bbsp/macfilter/macfilter.asp", 
            data=payload
        )
        if resp.status_code == 200:
            return jsonify({"success": True, "message": f"Đã {'bật' if enable else 'tắt'} bộ lọc MAC thành công."})
        return jsonify({"error": f"Router trả về mã lỗi: {resp.status_code}"}), 500
    except Exception as e:
        return jsonify({"error": f"Thao tác thất bại: {str(e)}"}), 500

@app.route("/api/macfilter/mode", methods=["POST"])
def change_mac_filter_mode():
    data = request.json or {}
    mode = data.get("mode") # "0" (Blacklist) or "1" (Whitelist)
    token = data.get("token")
    
    if mode is None or not token:
        return jsonify({"error": "Thiếu tham số 'mode' hoặc 'token'"}), 400
        
    payload = {
        "x.MacFilterPolicy": mode,
        "x.X_HW_Token": token
    }
    
    try:
        resp = make_router_request(
            "POST", 
            "/html/bbsp/macfilter/set.cgi?x=InternetGatewayDevice.X_HW_Security&RequestFile=html/bbsp/macfilter/macfilter.asp", 
            data=payload
        )
        if resp.status_code == 200:
            mode_text = "Blacklist (Chặn)" if mode == "0" else "Whitelist (Cho phép)"
            return jsonify({"success": True, "message": f"Đã chuyển chế độ lọc sang: {mode_text}."})
        return jsonify({"error": f"Router trả về mã lỗi: {resp.status_code}"}), 500
    except Exception as e:
        return jsonify({"error": f"Thao tác thất bại: {str(e)}"}), 500

@app.route("/api/macfilter/add", methods=["POST"])
def add_mac_filter_rule():
    data = request.json or {}
    mac = data.get("mac")
    token = data.get("token")
    
    if not mac or not token:
        return jsonify({"error": "Thiếu tham số 'mac' hoặc 'token'"}), 400
        
    # Format MAC to standard router expectation
    mac_formatted = mac.lower()
    
    payload = {
        "x.SourceMACAddress": mac_formatted,
        "x.X_HW_Token": token
    }
    
    try:
        resp = make_router_request(
            "POST", 
            "/html/bbsp/macfilter/add.cgi?x=InternetGatewayDevice.X_HW_Security.MacFilter&RequestFile=html/bbsp/macfilter/macfilter.asp", 
            data=payload
        )
        if resp.status_code == 200:
            return jsonify({"success": True, "message": f"Đã thêm thiết bị {mac_formatted} vào danh sách lọc."})
        return jsonify({"error": f"Router trả về mã lỗi: {resp.status_code}"}), 500
    except Exception as e:
        return jsonify({"error": f"Thao tác thất bại: {str(e)}"}), 500

@app.route("/api/macfilter/delete", methods=["POST"])
def delete_mac_filter_rule():
    data = request.json or {}
    domain = data.get("domain") # e.g. InternetGatewayDevice.X_HW_Security.MacFilter.1
    token = data.get("token")
    
    if not domain or not token:
        return jsonify({"error": "Thiếu tham số 'domain' hoặc 'token'"}), 400
        
    # Huawei del.cgi expects the domain key with empty string, e.g. "InternetGatewayDevice.X_HW_Security.MacFilter.1": ""
    payload = {
        domain: "",
        "x.X_HW_Token": token
    }
    
    try:
        resp = make_router_request(
            "POST", 
            "/html/bbsp/macfilter/del.cgi?x=InternetGatewayDevice.X_HW_Security.MacFilter&RequestFile=html/bbsp/macfilter/macfilter.asp", 
            data=payload
        )
        if resp.status_code == 200:
            return jsonify({"success": True, "message": "Đã xoá quy tắc lọc MAC thành công."})
        return jsonify({"error": f"Router trả về mã lỗi: {resp.status_code}"}), 500
    except Exception as e:
        return jsonify({"error": f"Thao tác thất bại: {str(e)}"}), 500

if __name__ == "__main__":
    # Perform initial login check on start
    try:
        do_router_login()
    except Exception as e:
        print(f"Initial router login attempt failed: {e}")
        
    port = int(os.environ.get("PORT", 5000))
    print(f"Starting Router Manager Backend on port {port}...")
    app.run(host="0.0.0.0", port=port, debug=False)
