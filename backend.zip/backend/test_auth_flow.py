"""
Test script kiểm tra:
1. Tài khoản mặc định (haing / 291945) hoạt động đúng
2. Rule mật khẩu 6 ký tự hoạt động (từ chối < 6, chấp nhận >= 6)
3. Luồng đăng ký và đăng nhập cơ bản
"""
import sys
import os
import json
import requests
import time
import subprocess
import signal

BACKEND_URL = "http://127.0.0.1:5000/api"

# ============================================================
# Các test case trực tiếp qua API (cần backend + mock router chạy)
# ============================================================

def test_register_password_rule():
    """Kiểm tra rule mật khẩu 6 ký tự qua API register"""
    print("\n" + "="*60)
    print("TEST 1: Register với mật khẩủ < 6 ký tự (phải bị từ chối)")
    print("="*60)
    
    # Test 1a: password 5 ký tự -> bị từ chối
    resp = requests.post(f"{BACKEND_URL}/auth/register", json={
        "username": "testuser1",
        "password": "12345"
    })
    result = resp.json()
    print(f"  Password '12345' (5 ký tự): status={resp.status_code}")
    print(f"  Response: {json.dumps(result, ensure_ascii=False)}")
    assert resp.status_code == 400, f"Expected 400, got {resp.status_code}"
    assert "6 ký tự" in result.get("error", ""), f"Expected error about 6 chars, got: {result}"
    print("  ✅ PASS: Mật khẩủ 5 ký tự bị từ chối đúng")
    
    # Test 1b: password 6 ký tự -> được chấp nhận
    print("\n  Test 1b: Password 6 ký tự -> được chấp nhận")
    resp = requests.post(f"{BACKEND_URL}/auth/register", json={
        "username": "testuser2",
        "password": "123456"
    })
    result = resp.json()
    print(f"  Password '123456' (6 ký tự): status={resp.status_code}")
    print(f"  Response: {json.dumps(result, ensure_ascii=False)}")
    # Có thể thành công hoặc báo trùng username nếu đã tồn tại, nhưng không được báo lỗi độ dài
    assert resp.status_code != 400 or "6 ký tự" not in result.get("error", ""), \
        f"Password 6 ký tự không nên bị từ chối vì độ dài: {result}"
    print("  ✅ PASS: Mật khẩủ 6 ký tự không bị từ chối vì độ dài")
    
    # Test 1c: password rỗng -> bị từ chối
    print("\n  Test 1c: Password rỗng -> bị từ chối")
    resp = requests.post(f"{BACKEND_URL}/auth/register", json={
        "username": "testuser3",
        "password": ""
    })
    result = resp.json()
    print(f"  Password rỗng: status={resp.status_code}")
    print(f"  Response: {json.dumps(result, ensure_ascii=False)}")
    assert resp.status_code == 400, f"Expected 400, got {resp.status_code}"
    print("  ✅ PASS: Password rỗng bị từ chối đúng")
    
    print("\n✅ TEST 1 HOÀN TẤT: Rule mật khẩu 6 ký tự hoạt động đúng!")


def test_default_admin_login():
    """Kiểm tra đăng nhập với tài khoản mặc định haing/291945"""
    print("\n" + "="*60)
    print("TEST 2: Đăng nhập với tài khoản mặc định (haing / 291945)")
    print("="*60)
    
    # Test đăng nhập đúng
    resp = requests.post(f"{BACKEND_URL}/auth/login", json={
        "username": "haing",
        "password": "291945"
    })
    result = resp.json()
    print(f"  Login haing/291945: status={resp.status_code}")
    print(f"  Response: {json.dumps(result, ensure_ascii=False)}")
    
    if resp.status_code == 200:
        print("  ✅ PASS: Đăng nhập tài khoản mặc định thành công!")
        token = result.get("token", "")
        return token
    elif resp.status_code == 403 and "chưa được kích hoạt" in result.get("error", ""):
        print("  ⚠️  Tài khoản tồn tại nhưng chưa active (cần kiểm tra ensure_default_admin_user)")
        return None
    else:
        print(f"  ❌ FAIL: {result}")
        return None


def test_login_wrong_password():
    """Kiểm tra đăng nhập sai mật khẩu"""
    print("\n" + "="*60)
    print("TEST 3: Đăng nhập sai mật khẩu")
    print("="*60)
    
    resp = requests.post(f"{BACKEND_URL}/auth/login", json={
        "username": "haing",
        "password": "wrongpass"
    })
    result = resp.json()
    print(f"  Login haing/wrongpass: status={resp.status_code}")
    print(f"  Response: {json.dumps(result, ensure_ascii=False)}")
    assert resp.status_code == 400, f"Expected 400, got {resp.status_code}"
    assert "Sai mật khẩu" in result.get("error", ""), f"Expected 'Sai mật khẩu', got: {result}"
    print("  ✅ PASS: Sai mật khẩu bị từ chối đúng")


def test_login_nonexistent_user():
    """Kiểm tra đăng nhập với tài khoản không tồn tại"""
    print("\n" + "="*60)
    print("TEST 4: Đăng nhập với tài khoản không tồn tại")
    print("="*60)
    
    resp = requests.post(f"{BACKEND_URL}/auth/login", json={
        "username": "nonexistent_user_xyz",
        "password": "somepass"
    })
    result = resp.json()
    print(f"  Login nonexistent_user: status={resp.status_code}")
    print(f"  Response: {json.dumps(result, ensure_ascii=False)}")
    assert resp.status_code == 400, f"Expected 400, got {resp.status_code}"
    assert "không tồn tại" in result.get("error", ""), f"Expected 'không tồn tại', got: {result}"
    print("  ✅ PASS: Tài khoản không tồn tại bị từ chối đúng")


def test_register_duplicate():
    """Kiểm tra đăng ký username trùng"""
    print("\n" + "="*60)
    print("TEST 5: Đăng ký username trùng")
    print("="*60)
    
    # Đăng ký user mới
    unique_user = f"dup_test_{int(time.time())}"
    resp = requests.post(f"{BACKEND_URL}/auth/register", json={
        "username": unique_user,
        "password": "123456"
    })
    print(f"  Register lần 1 ({unique_user}): status={resp.status_code}")
    print(f"  Response: {json.dumps(resp.json(), ensure_ascii=False)}")
    
    # Đăng ký lại cùng username
    resp = requests.post(f"{BACKEND_URL}/auth/register", json={
        "username": unique_user,
        "password": "123456"
    })
    result = resp.json()
    print(f"  Register lần 2 (trùng): status={resp.status_code}")
    print(f"  Response: {json.dumps(result, ensure_ascii=False)}")
    assert resp.status_code == 400, f"Expected 400, got {resp.status_code}"
    assert "đã tồn tại" in result.get("error", ""), f"Expected 'đã tồn tại', got: {result}"
    print("  ✅ PASS: Đăng ký trùng username bị từ chối đúng")


def test_auth_roundtrip(token):
    """Kiểm tra xác thực session: dùng token để gọi API"""
    print("\n" + "="*60)
    print("TEST 6: Xác thực session (dùng token gọi /api/auth/me)")
    print("="*60)
    
    if not token:
        print("  ⏭️  SKIP: Không có token để test")
        return
    
    headers = {"Authorization": f"Bearer {token}"}
    resp = requests.get(f"{BACKEND_URL}/auth/me", headers=headers)
    result = resp.json()
    print(f"  GET /auth/me: status={resp.status_code}")
    print(f"  Response: {json.dumps(result, ensure_ascii=False)}")
    assert resp.status_code == 200, f"Expected 200, got {resp.status_code}"
    assert "haing" in result.get("username", "").lower(), f"Expected username 'haing', got: {result}"
    print("  ✅ PASS: Session token hoạt động đúng")


def test_unauthorized_access():
    """Kiểm tra truy cập API khi không có token"""
    print("\n" + "="*60)
    print("TEST 7: Truy cập API khi không có token")
    print("="*60)
    
    resp = requests.get(f"{BACKEND_URL}/auth/me")
    print(f"  GET /auth/me (no token): status={resp.status_code}")
    assert resp.status_code == 401, f"Expected 401, got {resp.status_code}"
    print("  ✅ PASS: Truy cập không token bị từ chối đúng")
    
    resp = requests.get(f"{BACKEND_URL}/auth/me", headers={"Authorization": "Bearer invalid_token"})
    print(f"  GET /auth/me (invalid token): status={resp.status_code}")
    assert resp.status_code == 401, f"Expected 401, got {resp.status_code}"
    print("  ✅ PASS: Truy cập token sai bị từ chối đúng")


def test_logout(token):
    """Kiểm tra đăng xuất"""
    print("\n" + "="*60)
    print("TEST 8: Đăng xuất")
    print("="*60)
    
    if not token:
        print("  ⏭️  SKIP: Không có token để test")
        return
    
    headers = {"Authorization": f"Bearer {token}"}
    resp = requests.post(f"{BACKEND_URL}/auth/logout", headers=headers)
    result = resp.json()
    print(f"  POST /auth/logout: status={resp.status_code}")
    print(f"  Response: {json.dumps(result, ensure_ascii=False)}")
    assert resp.status_code == 200, f"Expected 200, got {resp.status_code}"
    print("  ✅ PASS: Đăng xuất thành công")
    
    # Kiểm tra token đã hết hạn
    resp = requests.get(f"{BACKEND_URL}/auth/me", headers=headers)
    print(f"  GET /auth/me (after logout): status={resp.status_code}")
    assert resp.status_code == 401, f"Expected 401, got {resp.status_code}"
    print("  ✅ PASS: Token hết hạn sau khi logout")


def check_backend_health():
    """Kiểm tra backend đã chạy chưa"""
    try:
        resp = requests.get(f"{BACKEND_URL}/auth/login", timeout=2)
        return True
    except requests.exceptions.ConnectionError:
        return False


def run_all_tests():
    """Chạy tất cả các test"""
    print("="*60)
    print("  KIỂM TRA TÀI KHOẢN MẶC ĐỊNH & RULE MẬT KHẨU")
    print("="*60)
    
    # Kiểm tra backend đã chạy chưa
    if not check_backend_health():
        print("\n❌ Backend chưa chạy! Hãy chạy backend trước:")
        print("   cd backend && python app.py")
        print("   (và mock router: python test_mock_router.py)")
        return False
    
    print("\n✅ Backend đang chạy, bắt đầu kiểm tra...\n")
    
    try:
        # Test rule mật khẩu
        test_register_password_rule()
        
        # Test đăng nhập mặc định
        token = test_default_admin_login()
        
        # Test sai mật khẩu
        test_login_wrong_password()
        
        # Test user không tồn tại
